# Common Controls library for arduino projects
Contains the following classes:
- Backlight to manage the LCD display backlight intensivity
- Button to manage the push button
- Encoder to manage the rotary encoder
- Switch to manage reed switch
